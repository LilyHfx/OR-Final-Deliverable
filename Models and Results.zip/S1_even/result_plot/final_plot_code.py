import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

# 🔹 Load data
course_df = pd.read_csv("/Users/huangfeixue/Desktop/学校/Edinburgh/Y4/Topics in Applied Operational Research/Project/S1_even/filtered_course_data_S1_even.csv")
student_df = pd.read_csv("/Users/huangfeixue/Desktop/学校/Edinburgh/Y4/Topics in Applied Operational Research/Project/S1_even/Student_S1.csv")
c1_10_df = pd.read_csv("/Users/huangfeixue/Desktop/学校/Edinburgh/Y4/Topics in Applied Operational Research/Project/S1_even/constraint1-10/constraint1-10_full_attendance_matrix.csv")

# 🔹 Label model
c1_10_df["Model"] = "Constraint 1-10"
attendance_df = c1_10_df.copy()

# ============================
# 🎯 Student-Level Summary
# ============================

course_durations = course_df[["course_index", "Lecture duration by week", 
                              "Normal Workshop Duration", "Computer Workshop Duration"]].fillna(0)

student_courses = student_df.merge(course_durations, on="course_index", how="left")

ideal_attendance = (
    student_courses.groupby("student_index")[["Lecture duration by week", 
                                              "Normal Workshop Duration", 
                                              "Computer Workshop Duration"]]
    .sum()
    .sum(axis=1)
    .reset_index(name="Ideal_Attendance_Hours")
)

actual_attendance = (
    attendance_df[attendance_df["Attended"] == 1]
    .groupby(["Model", "Student"])
    .size()
    .reset_index(name="Actual_Attendance_Hours")
)

student_summary = actual_attendance.merge(
    ideal_attendance, left_on="Student", right_on="student_index", how="left"
)
student_summary["Missed_Hours"] = student_summary["Ideal_Attendance_Hours"] - student_summary["Actual_Attendance_Hours"]
student_summary["Attendance_Percentage"] = (
    student_summary["Actual_Attendance_Hours"] / student_summary["Ideal_Attendance_Hours"] * 100
).round(2)

# ===============================
# 🎯 Course Timeslot Summary
# ===============================

students_per_course = student_df.groupby("course_index")["student_index"].nunique().reset_index()
students_per_course.columns = ["Course", "Expected_Students"]

course_timeslot_attendance = (
    attendance_df[attendance_df["Attended"] == 1]
    .groupby(["Model", "Course", "Day", "Hour", "Activity Type"])
    .size()
    .reset_index(name="Attendance_Number")
)

course_timeslot_summary = course_timeslot_attendance.merge(
    students_per_course, on="Course", how="left"
)
course_timeslot_summary["Attendance_Percentage"] = (
    course_timeslot_summary["Attendance_Number"] / course_timeslot_summary["Expected_Students"] * 100
).round(2)

# 💾 Export to CSV
student_summary.to_csv("/Users/huangfeixue/Desktop/学校/Edinburgh/Y4/Topics in Applied Operational Research/Project/S1_even/result_plot/S1_even_student_attendance_summary_all_models.csv", index=False)
course_timeslot_summary.to_csv("/Users/huangfeixue/Desktop/学校/Edinburgh/Y4/Topics in Applied Operational Research/Project/S1_even/result_plot/S1_even_course_timeslot_attendance_summary_all_models.csv", index=False)

# 🔧 Global Plot Settings
plt.rcParams.update({
    "axes.titlesize": 18,
    "axes.labelsize": 14,
    "xtick.labelsize": 12,
    "ytick.labelsize": 12,
    "legend.fontsize": 12,
    "legend.title_fontsize": 14
})

# ===============================
# 📊 Student Attendance Histogram
# ===============================
plt.figure(figsize=(10, 6))
bins = list(range(50, 110, 5))
subset = student_summary
counts, bins_plot, patches = plt.hist(subset["Attendance_Percentage"], bins=bins,
                                      alpha=0.8, edgecolor='black', color="#ff7f0e")

for count, patch in zip(counts, patches):
    if count > 0:
        plt.text(patch.get_x() + patch.get_width() / 2, count + 1, f'{int(count)}',
                 ha='center', va='bottom', fontsize=10)

plt.title("Student Attendance Percentage Distribution", fontsize=20)
plt.xlabel("Attendance Percentage")
plt.ylabel("Number of Students")
plt.xlim(50, 105)
plt.ylim(0, max(counts) + 10)
plt.tight_layout()
plt.savefig("/Users/huangfeixue/Desktop/学校/Edinburgh/Y4/Topics in Applied Operational Research/Project/S1_even/result_plot/S1_even_student_attendance_hist.pdf")
plt.show()

# ===============================
# 📊 Course Timeslot Histogram
# ===============================
plt.figure(figsize=(10, 6))
subset = course_timeslot_summary
counts, bins_plot, patches = plt.hist(subset["Attendance_Percentage"], bins=bins,
                                      alpha=0.8, edgecolor='black', color="#ff7f0e")
for count, patch in zip(counts, patches):
    if count > 0:
        plt.text(patch.get_x() + patch.get_width() / 2, count + 0.5, f'{int(count)}',
                 ha='center', va='bottom', fontsize=10)

plt.title("Course Timeslot Attendance Percentage Distribution", fontsize=20)
plt.xlabel("Attendance Percentage")
plt.ylabel("Number of Timeslots")
plt.xlim(50, 105)
plt.ylim(0, max(counts) + 5)
plt.tight_layout()
plt.savefig("/Users/huangfeixue/Desktop/学校/Edinburgh/Y4/Topics in Applied Operational Research/Project/S1_even/result_plot/S1_even_course_attendance_hist.pdf")
plt.show()

# ===============================
# 📊 Missed Hours Bar Chart
# ===============================
missed_hour_counts = (
    student_summary["Missed_Hours"]
    .value_counts()
    .sort_index()
)

plt.figure(figsize=(10, 6))
bars = plt.bar(missed_hour_counts.index.astype(str), missed_hour_counts.values, color="#ff7f0e")
for bar in bars:
    height = bar.get_height()
    plt.text(bar.get_x() + bar.get_width()/2, height + 1, f'{int(height)}',
             ha='center', va='bottom', fontsize=10)

plt.title("Student Missed Hours Distribution", fontsize=20)
plt.xlabel("Missed Attendance Hours")
plt.ylabel("Number of Students")
plt.tight_layout()
plt.savefig("/Users/huangfeixue/Desktop/学校/Edinburgh/Y4/Topics in Applied Operational Research/Project/S1_even/result_plot/S1_even_student_missed_hours_bar.pdf")
plt.show()

# ===============================
# 📊 Student Daily Workload Violin Plot
# ===============================
df_filtered = attendance_df[(attendance_df["Model"] == "Constraint 1-10") & (attendance_df["Attended"] == 1)]
workload = df_filtered.groupby(["Student", "Day"]).size().reset_index(name="Workload_Hours")
workload["Day"] = pd.Categorical(workload["Day"], categories=["Monday", "Tuesday", "Wednesday", "Thursday", "Friday"], ordered=True)

plt.figure(figsize=(12, 6))
sns.violinplot(data=workload, x="Day", y="Workload_Hours", inner="box", scale="width", palette="pastel")
plt.title("Student Daily Workload Distribution (Constraint 1-10)", fontsize=18)
plt.xlabel("Day of Week")
plt.ylabel("Total Hours Attended")
plt.tight_layout()
plt.savefig("/Users/huangfeixue/Desktop/学校/Edinburgh/Y4/Topics in Applied Operational Research/Project/S1_even/result_plot/S1_even_student_daily_workload_violin.pdf")
plt.show()

# ===============================
# 📊 Heatmap of Course Timeslot Usage
# ===============================
df_10 = course_timeslot_summary[course_timeslot_summary["Model"] == "Constraint 1-10"]
hour_order = ["9:00", "10:00", "11:00", "12:00", "13:00", "14:00", "15:00", "16:00", "17:00"]
df_10["Hour"] = pd.Categorical(df_10["Hour"], categories=hour_order, ordered=True)
heatmap_data = df_10.groupby(["Day", "Hour"]).size().unstack(fill_value=0)
day_order = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday"]
heatmap_data = heatmap_data.reindex(day_order)

plt.figure(figsize=(14, 6))
sns.heatmap(heatmap_data, cmap="YlGnBu", linewidths=0.5, linecolor="gray", annot=True, fmt="d")
plt.title("Heatmap of Scheduled Course Timeslots per Time Slot (Constraint 1-10)", fontsize=18)
plt.xlabel("Hour")
plt.ylabel("Day")
plt.xticks(rotation=45)
plt.tight_layout()
plt.savefig("/Users/huangfeixue/Desktop/学校/Edinburgh/Y4/Topics in Applied Operational Research/Project/S1_even/result_plot/S1_even_heatmap_constraint1-10.pdf")
plt.show()
