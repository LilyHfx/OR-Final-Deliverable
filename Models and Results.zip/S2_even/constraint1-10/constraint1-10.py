import gurobipy as gp
from gurobipy import GRB 
import pandas as pd
import matplotlib.pyplot as plt

# ✅ Load Data
course_data_path = "/Users/huangfeixue/Desktop/学校/Edinburgh/Y4/Topics in Applied Operational Research/Project/S2_even/filtered_course_data_S2_even.csv"
student_data_path = "/Users/huangfeixue/Desktop/学校/Edinburgh/Y4/Topics in Applied Operational Research/Project/S2_even/Student_S2.csv"

course_data = pd.read_csv(course_data_path)
student_data = pd.read_csv(student_data_path)

# ✅ Convert course durations to integers to avoid float issues
course_data["Lecture duration by week"] = course_data["Lecture duration by week"].astype(int)
course_data["Normal Workshop Duration"] = course_data["Normal Workshop Duration"].astype(int)
course_data["Computer Workshop Duration"] = course_data["Computer Workshop Duration"].astype(int)

# ✅ Initialize Gurobi Model
time_slots = range(1, 46)  # 9 hours/day * 5 days = 45 slots
students = student_data["student_index"].unique()
courses = course_data["course_index"].unique()

course_durations = course_data.set_index("course_index")[
    ["Lecture duration by week", "Normal Workshop Duration", "Computer Workshop Duration"]
].to_dict(orient="index")

S = []
for s in students:
    student_course = student_data[student_data['student_index'] == s]["course_index"]
    for c in student_course:
        if c not in courses:
            S.append(s)

students = [s for s in students if s not in S]

model = gp.Model("Student_Timetabling")
model.ModelSense = GRB.MAXIMIZE

# ✅ Define Decision Variables
a_L, a_N, a_C = {}, {}, {}
for s in students:
    student_course = student_data[student_data['student_index'] == s]["course_index"].tolist() 
    for c in student_course:
        for d in range(5):
            for h in range(9):
                a_L[s, c, d, h] = model.addVar(vtype=GRB.BINARY, name=f"a_L_{s}_{c}_{d}_{h}")
                a_N[s, c, d, h] = model.addVar(vtype=GRB.BINARY, name=f"a_N_{s}_{c}_{d}_{h}")
                a_C[s, c, d, h] = model.addVar(vtype=GRB.BINARY, name=f"a_C_{s}_{c}_{d}_{h}")

x_L, x_N, x_C = {}, {}, {} 
for c in courses:
    for d in range(5):
        for h in range(9):
            x_L[c,d,h] = model.addVar(vtype=GRB.BINARY, name=f"x_L_{c}_{d}_{h}")
            x_N[c,d,h] = model.addVar(vtype=GRB.BINARY, name=f"x_N_{c}_{d}_{h}")
            x_C[c,d,h] = model.addVar(vtype=GRB.BINARY, name=f"x_C_{c}_{d}_{h}")

# ✅ Objective Function: Maximize Student Attendance Hours
objective = 0
for s in students:
    student_course = student_data[student_data['student_index'] == s]["course_index"].tolist() 
    for c in student_course:
        objective += gp.quicksum(a_L[s, c, d, h] for d in range(5) for h in range(9))
        objective += gp.quicksum(a_N[s, c, d, h] for d in range(5) for h in range(9))
        objective += gp.quicksum(a_C[s, c, d, h] for d in range(5) for h in range(9))

model.setObjective(objective, GRB.MAXIMIZE)

# ✅ Constraints (1-7)
for c in courses:
    duration_L = int(course_durations.get(c, {}).get("Lecture duration by week", 0))
    model.addConstr(gp.quicksum(x_L[c,d,h] for d in range(5) for h in range(9)) == duration_L, name=f'Lecture_hours_{c}')

for c in courses:
    model.addConstr(gp.quicksum(x_N[c,d,h] for d in range(5) for h in range(9)) == 1, name=f'c1N[{c}]')
    model.addConstr(gp.quicksum(x_C[c,d,h] for d in range(5) for h in range(9)) == 1, name=f'c1C[{c}]')

for c in courses:
    duration_N = int(course_durations.get(c, {}).get("Normal Workshop Duration", 0))
    duration_C = int(course_durations.get(c, {}).get("Computer Workshop Duration", 0))
    for d in range(5):
        for h in range(9):
            model.addConstr(x_N[c,d,h]*h + duration_N <= 8+1)
            model.addConstr(x_C[c,d,h]*h + duration_C <= 8+1)

for c in courses:
    for d in range(5):
        for h in range(9):
            model.addConstr(
                x_L[c, d, h] + x_N[c, d, h] + x_C[c, d, h] <= 1,
                name=f'no_overlap_activity_{c}_{d}_{h}'
            )

for s in students:
    student_courses = student_data[student_data['student_index'] == s]['course_index'].tolist()
    for c in student_courses:
        duration_N = int(course_durations.get(c, {}).get("Normal Workshop Duration", 0))
        duration_C = int(course_durations.get(c, {}).get("Computer Workshop Duration", 0))
        for d in range(5):
            for h in range(9):
                model.addConstr(a_L[s, c, d, h] <= x_L[c, d, h])
                for offset in range(duration_N):
                    if h - offset >= 0:
                        model.addConstr(a_N[s, c, d, h] <= x_N[c, d, h - offset])
                for offset in range(duration_C):
                    if h - offset >= 0:
                        model.addConstr(a_C[s, c, d, h] <= x_C[c, d, h - offset])

for s in students:
    student_courses = student_data[student_data['student_index'] == s]['course_index'].tolist()
    for d in range(5):
        for h in range(9):
            model.addConstr(
                gp.quicksum(a_L[s, c, d, h] for c in student_courses) + 
                gp.quicksum(a_N[s, c, d, h] for c in student_courses) + 
                gp.quicksum(a_C[s, c, d, h] for c in student_courses) <= 1
            )

for s in students:
    student_courses = student_data[student_data['student_index'] == s]['course_index'].tolist()
    for c in student_courses:
        duration_L = int(course_durations.get(c, {}).get("Lecture duration by week", 0))
        duration_N = int(course_durations.get(c, {}).get("Normal Workshop Duration", 0))
        duration_C = int(course_durations.get(c, {}).get("Computer Workshop Duration", 0))
        model.addConstr(gp.quicksum(a_L[s, c, d, h] for d in range(5) for h in range(9)) <= duration_L)
        model.addConstr(gp.quicksum(a_N[s, c, d, h] for d in range(5) for h in range(9)) <= duration_N)
        model.addConstr(gp.quicksum(a_C[s, c, d, h] for d in range(5) for h in range(9)) <= duration_C)

# ✅ Constraint 8
for s in students:
    student_courses = student_data[student_data['student_index'] == s]['course_index'].tolist()
    for c in student_courses:
        for d in range(5):
            attend_hours = gp.quicksum(a_L[s, c, d, h] for h in range(9))
            model.addConstr(attend_hours <= 2)
            for h in range(8):
                model.addConstr(attend_hours <= 1 + a_L[s, c, d, h] * a_L[s, c, d, h+1])

# ✅ Constraint 9: Work-life balance constraints
# Limit students to at most 5 activities per day
for s in students:
    for d in range(5):
        daily_activities = gp.quicksum(
            a_L[s, c, d, h] + a_N[s, c, d, h] + a_C[s, c, d, h]
            for c in student_data[student_data['student_index'] == s]['course_index'].tolist()
            for h in range(9)
        )
        model.addConstr(daily_activities <= 7, name=f'max_activities_per_day_{s}_{d}')

# ✅ Workshop Priority Over Lecture
for s in students:
    student_courses = student_data[student_data['student_index'] == s]['course_index'].tolist()
    for c in student_courses:
        for d in range(5):
            for h in range(9):
                # Normal Workshop overrides Lecture
                model.addConstr(a_L[s, c, d, h] <= 1 - a_N[s, c, d, h], name=f'priority_workshop_over_lecture_{s}_{c}_{d}_{h}')
                # Computer Workshop overrides both Normal Workshop and Lecture
                model.addConstr(a_N[s, c, d, h] <= 1 - a_C[s, c, d, h], name=f'priority_computer_over_workshop_{s}_{c}_{d}_{h}')
                model.addConstr(a_L[s, c, d, h] <= 1 - a_C[s, c, d, h], name=f'priority_computer_over_lecture_{s}_{c}_{d}_{h}')


# ✅ Constraint 10
MAX_MISSED_HOURS = 8

for s in students:
    student_courses = student_data[student_data['student_index'] == s]['course_index'].tolist()

    ideal_attendance = sum(
        course_durations.get(c, {}).get("Lecture duration by week", 0) +
        course_durations.get(c, {}).get("Normal Workshop Duration", 0) +
        course_durations.get(c, {}).get("Computer Workshop Duration", 0)
        for c in student_courses
    )

    actual_attendance = gp.quicksum(
        a_L[s, c, d, h] + a_N[s, c, d, h] + a_C[s, c, d, h]
        for c in student_courses
        for d in range(5)
        for h in range(9)
    )

    missed_hours = ideal_attendance - actual_attendance

    model.addConstr(missed_hours <= MAX_MISSED_HOURS, name=f'miss_hours_limit_{s}')



# ✅ Solve Model
model.Params.MIPGap = 0.001            
model.Params.timelimit = 1000
model.optimize()

# ✅ Build course_schedule after solving the model
course_schedule = {}
slots_per_day = 9

for (c, d, h), var in x_L.items():
    if var.X > 0.5:
        course_schedule.setdefault(c, []).append((d, h))

for (c, d, h), var in x_N.items():
    if var.X > 0.5:
        duration_N = int(course_durations[c]["Normal Workshop Duration"])
        for offset in range(duration_N):
            if h + offset < slots_per_day:
                course_schedule.setdefault(c, []).append((d, h + offset))

for (c, d, h), var in x_C.items():
    if var.X > 0.5:
        duration_C = int(course_durations[c]["Computer Workshop Duration"])
        for offset in range(duration_C):
            if h + offset < slots_per_day:
                course_schedule.setdefault(c, []).append((d, h + offset))


# Step 7️⃣: Export full attendance matrix (per student, per course, per time slot)
attendance_matrix = []

for s in students:
    student_courses = student_data[student_data['student_index'] == s]['course_index'].tolist()
    for c in student_courses:
        if c in course_schedule:
            for d, h in course_schedule[c]:
                activity_type = None
                scheduled = 0
                attended = 0

                if (c, d, h) in x_L and x_L[c, d, h].X > 0.5:
                    activity_type = "Lecture"
                    scheduled = 1
                    if (s, c, d, h) in a_L and a_L[s, c, d, h].X > 0.5:
                        attended = 1

                elif (c, d, h) in x_N and any(
                    x_N[c, d, h - offset].X > 0.5
                    for offset in range(course_durations[c]["Normal Workshop Duration"])
                    if h - offset >= 0
                ):
                    activity_type = "Workshop"
                    scheduled = 1
                    if (s, c, d, h) in a_N and a_N[s, c, d, h].X > 0.5:
                        attended = 1

                elif (c, d, h) in x_C and any(
                    x_C[c, d, h - offset].X > 0.5
                    for offset in range(course_durations[c]["Computer Workshop Duration"])
                    if h - offset >= 0
                ):
                    activity_type = "Computer Workshop"
                    scheduled = 1
                    if (s, c, d, h) in a_C and a_C[s, c, d, h].X > 0.5:
                        attended = 1

                if scheduled:
                    attendance_matrix.append({
                        "Student": s,
                        "Course": c,
                        "Day": ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday"][d],
                        "Hour": ["9:00", "10:00", "11:00", "12:00", "13:00", "14:00", "15:00", "16:00", "17:00"][h],
                        "Activity Type": activity_type,
                        "Scheduled": scheduled,
                        "Attended": attended
                    })

attendance_matrix_df = pd.DataFrame(attendance_matrix)
attendance_matrix_df.to_csv("/Users/huangfeixue/Desktop/学校/Edinburgh/Y4/Topics in Applied Operational Research/Project/S2_even/constraint1-10/constraint1-10_full_attendance_matrix.csv", index=False)
print("✅ Exported full student-course-time attendance matrix!")
