
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import os

# 🔹 Load data
course_df = pd.read_csv("/Users/huangfeixue/Desktop/学校/Edinburgh/Y4/Topics in Applied Operational Research/Project/S1_odd/filtered_course_data_S1_odd.csv")
student_df = pd.read_csv("/Users/huangfeixue/Desktop/学校/Edinburgh/Y4/Topics in Applied Operational Research/Project/S1_odd/Student_S1.csv")

baseline_df = pd.read_csv("/Users/huangfeixue/Desktop/学校/Edinburgh/Y4/Topics in Applied Operational Research/Project/S1_odd/baseline/baseline_full_attendance_matrix.csv")
c1_8_df = pd.read_csv("/Users/huangfeixue/Desktop/学校/Edinburgh/Y4/Topics in Applied Operational Research/Project/S1_odd/constraint1-8/constraint1-8_full_attendance_matrix.csv")
c1_9_df = pd.read_csv("/Users/huangfeixue/Desktop/学校/Edinburgh/Y4/Topics in Applied Operational Research/Project/S1_odd/constraint1-9/constraint1-9_full_attendance_matrix.csv")
c1_10_df = pd.read_csv("/Users/huangfeixue/Desktop/学校/Edinburgh/Y4/Topics in Applied Operational Research/Project/S1_odd/constraint1-10/constraint1-10_full_attendance_matrix.csv")

## 🔹 Label models
baseline_df["Model"] = "Baseline"
c1_8_df["Model"] = "Constraint 1-8"
c1_9_df["Model"] = "Constraint 1-9"
c1_10_df["Model"] = "Constraint 1-10"



# 🔹 Combine all models
attendance_df = pd.concat([baseline_df, c1_8_df, c1_9_df, c1_10_df], ignore_index=True)

# ============================
# 🎯 1. Student-Level Summary
# ============================

# Clean and prepare course durations
course_durations = course_df[["course_index", "Lecture duration by week", 
                              "Normal Workshop Duration", "Computer Workshop Duration"]].copy()
course_durations = course_durations.fillna(0)

# Merge course durations with student enrollments
student_courses = student_df.merge(course_durations, on="course_index", how="left")

# Calculate ideal attendance per student
ideal_attendance_per_student = (
    student_courses.groupby("student_index")[["Lecture duration by week", 
                                              "Normal Workshop Duration", 
                                              "Computer Workshop Duration"]]
    .sum()
    .sum(axis=1)
    .reset_index(name="Ideal_Attendance_Hours")
)

# Actual attendance per student from logs
actual_attendance_per_student = (
    attendance_df[attendance_df["Attended"] == 1]
    .groupby(["Model", "Student"])
    .size()
    .reset_index(name="Actual_Attendance_Hours")
)

# Merge ideal with actual
student_summary = actual_attendance_per_student.merge(
    ideal_attendance_per_student, left_on="Student", right_on="student_index", how="left"
)

# Final metrics
student_summary["Missed_Hours"] = (
    student_summary["Ideal_Attendance_Hours"] - student_summary["Actual_Attendance_Hours"]
)
student_summary["Attendance_Percentage"] = (
    student_summary["Actual_Attendance_Hours"] / student_summary["Ideal_Attendance_Hours"] * 100
).round(2)

# ===============================
# 🎯 2. Course Timeslot Summary
# ===============================

# Students per course (expected attendees)
students_per_course = student_df.groupby("course_index")["student_index"].nunique().reset_index()
students_per_course.columns = ["Course", "Expected_Students"]

# Actual attendance per timeslot
course_timeslot_attendance = (
    attendance_df[attendance_df["Attended"] == 1]
    .groupby(["Model", "Course", "Day", "Hour", "Activity Type"])
    .size()
    .reset_index(name="Attendance_Number")
)

# Merge with expected student count
course_timeslot_summary = course_timeslot_attendance.merge(
    students_per_course, on="Course", how="left"
)

course_timeslot_summary["Attendance_Percentage"] = (
    course_timeslot_summary["Attendance_Number"] / course_timeslot_summary["Expected_Students"] * 100
).round(2)

# -----------------------------
# 💾 Export both to CSV
# -----------------------------
# ✅ Rename model labels for clarity in plots and exports
model_rename_map = {
    "Baseline": "Model 1 (Baseline)",
    "Constraint 1-8": "Model 2",
    "Constraint 1-9": "Model 3",
    "Constraint 1-10": "Model 4 (Recommended)"
}

attendance_df["Model"] = attendance_df["Model"].replace(model_rename_map)
student_summary["Model"] = student_summary["Model"].replace(model_rename_map)
course_timeslot_summary["Model"] = course_timeslot_summary["Model"].replace(model_rename_map)

student_summary.to_csv("/Users/huangfeixue/Desktop/学校/Edinburgh/Y4/Topics in Applied Operational Research/Project/S1_odd/result_plot/S1_odd_student_attendance_summary_all_models.csv", index=False)
course_timeslot_summary.to_csv("/Users/huangfeixue/Desktop/学校/Edinburgh/Y4/Topics in Applied Operational Research/Project/S1_odd/result_plot/S1_odd_course_timeslot_attendance_summary_all_models.csv", index=False)


# Set global font sizes
plt.rcParams.update({
    "axes.titlesize": 25,
    "axes.labelsize": 20,
    "xtick.labelsize": 18,
    "ytick.labelsize": 18,
    "legend.fontsize": 18,
    "legend.title_fontsize": 20
})

# Define models and colors
# Define updated model order and colors
models = ["Model 1 (Baseline)", "Model 2", "Model 3", "Model 4 (Recommended)"]
colors = {
    "Model 1 (Baseline)": "#1f77b4",
    "Model 2": "#2ca02c",
    "Model 3": "#d62728",
    "Model 4 (Recommended)": "#ff7f0e",
}


# ------------------------
# Student Attendance Histogram
# ------------------------
fig, axes = plt.subplots(2, 2, figsize=(14, 10))
axes = axes.flatten()
bins = list(range(50, 110, 5))

for i, model in enumerate(models):
    color = colors[model]
    ax = axes[i]
    subset = student_summary[student_summary["Model"] == model]
    counts, bins_plot, patches = ax.hist(subset["Attendance_Percentage"], bins=bins,
                                         alpha=0.8, edgecolor='black', color=color)
    for count, patch in zip(counts, patches):
        if count > 0:
            ax.text(patch.get_x() + patch.get_width() / 2, count + 1, f'{int(count)}',
                    ha='center', va='bottom', fontsize=16)
    ax.set_title(f"{model}")
    ax.set_xlabel("Attendance Percentage")
    ax.set_ylabel("Number of Students")
    ax.set_xlim(50, 105)
    ax.set_ylim(0, 1200)

plt.suptitle("Student Attendance Percentage Distribution by Model", fontsize=28)
plt.tight_layout(rect=[0, 0, 1, 0.96])
plt.savefig("/Users/huangfeixue/Desktop/学校/Edinburgh/Y4/Topics in Applied Operational Research/Project/S1_odd/result_plot/S1_odd_student_attendance_hist.pdf")
plt.show()

# ------------------------
# Course Timeslot Histogram
# ------------------------
fig, axes = plt.subplots(2, 2, figsize=(14, 10))
axes = axes.flatten()

for i, model in enumerate(models):
    color = colors[model]
    ax = axes[i]
    subset = course_timeslot_summary[course_timeslot_summary["Model"] == model]
    counts, bins_plot, patches = ax.hist(subset["Attendance_Percentage"], bins=bins,
                                         alpha=0.8, edgecolor='black', color=color)
    for count, patch in zip(counts, patches):
        if count > 0:
            ax.text(patch.get_x() + patch.get_width() / 2, count + 0.5, f'{int(count)}',
                    ha='center', va='bottom', fontsize=16)
    ax.set_title(f"{model}")
    ax.set_xlabel("Attendance Percentage")
    ax.set_ylabel("Number of Timeslots")
    ax.set_xlim(50, 105)
    ax.set_ylim(0, 125)

plt.suptitle("Course Timeslot Attendance Percentage Distribution by Model", fontsize=28)
plt.tight_layout(rect=[0, 0, 1, 0.96])
plt.savefig("/Users/huangfeixue/Desktop/学校/Edinburgh/Y4/Topics in Applied Operational Research/Project/S1_odd/result_plot/S1_odd_course_attendance_hist.pdf")
plt.show()

# ------------------------
# Missed Hours Bar Chart
# ------------------------
missed_hour_table = (
    student_summary.groupby("Model")["Missed_Hours"]
    .value_counts()
    .unstack(fill_value=0)
    .sort_index(axis=1)
)

missed_levels = missed_hour_table.columns.tolist()
bar_width = 0.2
x = list(range(len(missed_levels)))

plt.figure(figsize=(14, 10))

for i, model in enumerate(models):
    heights = missed_hour_table.loc[model, missed_levels]
    offset_x = [val + bar_width * i for val in x]
    bars = plt.bar(offset_x, heights, width=bar_width, color=colors[model], label=model)
    for bar in bars:
        height = bar.get_height()
        if height > 0:
            plt.text(bar.get_x() + bar.get_width()/2, height + 13, f'{int(height)}',
                     ha='center', va='bottom', fontsize=15, rotation = 90)

plt.xticks([val + bar_width * 1.5 for val in x], missed_levels)
plt.xlabel("Missed Attendance Hours")
plt.ylabel("Number of Students")
plt.title("Student Missed Hours Distribution by Model", fontsize=28)
plt.legend(title="Model")
plt.ylim(0, 1500)
plt.tight_layout()
plt.savefig("/Users/huangfeixue/Desktop/学校/Edinburgh/Y4/Topics in Applied Operational Research/Project/S1_odd/result_plot/S1_odd_student_missed_hours_bar.pdf")
plt.show()


# --------------------------------------------
# 📌 Overall Summary Table by Model
# --------------------------------------------

# Student-level metrics
student_metrics = student_summary.groupby("Model").agg(
    Avg_Student_Attendance_Percentage=("Attendance_Percentage", "mean"),
    Avg_Missed_Hours=("Missed_Hours", "mean"),
    Percent_100_Attendance=("Attendance_Percentage", lambda x: (x == 100).mean() * 100)
).round(2)

# Course-level metrics
course_metrics = course_timeslot_summary.groupby("Model").agg(
    Avg_Course_Attendance_Percentage=("Attendance_Percentage", "mean")
).round(2)

# Combine into one summary table
overall_summary = student_metrics.join(course_metrics)

# --------------------------------------------
# 📌 Constraint Impact Table (Delta vs Baseline)
# --------------------------------------------

# Difference from baseline
baseline_vals = overall_summary.loc["Model 1 (Baseline)"]
delta_table = overall_summary.subtract(baseline_vals)
delta_table.loc["Baseline"] = 0  # Explicitly zero out Baseline row
delta_table = delta_table.round(2)

# --------------------------------------------
# 💾 Export both tables
# --------------------------------------------

overall_summary.to_csv("/Users/huangfeixue/Desktop/学校/Edinburgh/Y4/Topics in Applied Operational Research/Project/S1_odd/result_plot/S1_odd_overall_summary_by_model.csv")
delta_table.to_csv("/Users/huangfeixue/Desktop/学校/Edinburgh/Y4/Topics in Applied Operational Research/Project/S1_odd/result_plot/S1_odd_constraint_impact_vs_baseline.csv")


# --------------------------------------------
# Student workload
# --------------------------------------------
# 🔹 Filter for Constraint 1-10 and attended sessions only
df_filtered = attendance_df[(attendance_df["Model"] == "Model 4 (Recommended)") & (attendance_df["Attended"] == 1)]


# 🔹 Group by student and day, count number of hours (assuming each entry = 1 hour)
workload = df_filtered.groupby(["Student", "Day"]).size().reset_index(name="Workload_Hours")

# Ensure day order
workload["Day"] = pd.Categorical(workload["Day"],
                                 categories=["Monday", "Tuesday", "Wednesday", "Thursday", "Friday"],
                                 ordered=True)

# 🔹 Create a violin plot to show workload distribution per day
plt.figure(figsize=(14, 8))
sns.violinplot(data=workload, x="Day", y="Workload_Hours", inner="box", scale="width", palette="pastel")

plt.title("Student Daily Workload Distribution (Model 4 - Recommended)", fontsize=28)
plt.xlabel("Day of Week", fontsize=20)
plt.ylabel("Total Hours Attended", fontsize=20)
plt.xticks(fontsize=18)
plt.yticks(fontsize=18)
plt.grid(axis='y', linestyle='--', alpha=0.7)
plt.tight_layout()

# 🔹 Save as PDF (optional)
plt.savefig("/Users/huangfeixue/Desktop/学校/Edinburgh/Y4/Topics in Applied Operational Research/Project/S1_odd/result_plot/S1_odd_student_daily_workload_violin.pdf")

plt.show()

# --------------------------------------------
# Heatmap
# --------------------------------------------

# Filter for Constraint 1-10
df_10 = course_timeslot_summary[course_timeslot_summary["Model"] == "Model 4 (Recommended)"]

# 🔹 Ensure hour is ordered correctly (convert to categorical with ordering)
hour_order = ["9:00", "10:00", "11:00", "12:00", "13:00", "14:00", "15:00", "16:00", "17:00"]
df_10["Hour"] = pd.Categorical(df_10["Hour"], categories=hour_order, ordered=True)

# 🔹 Create heatmap matrix: count how many events are scheduled per (Day, Hour)
heatmap_data = df_10.groupby(["Day", "Hour"]).size().unstack(fill_value=0)

# 🔹 Ensure day order
day_order = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday"]
heatmap_data = heatmap_data.reindex(day_order)

# 🔹 Plot heatmap
plt.figure(figsize=(14, 8))
sns.heatmap(heatmap_data, cmap="YlGnBu", linewidths=0.5, linecolor="gray", annot=True, fmt="d", annot_kws={"size": 16} )

plt.title("Heatmap of Scheduled Course Timeslots (Model 4 - Recommended)", fontsize=28)
plt.ylabel("Day", fontsize=20)
plt.xticks(rotation=45)
plt.tight_layout()

plt.savefig("/Users/huangfeixue/Desktop/学校/Edinburgh/Y4/Topics in Applied Operational Research/Project/S1_odd/result_plot/S1_odd_heatmap_constraint1-10.pdf")

plt.show()